package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CheckoutPage {
    private WebDriver driver;

    private By billingContinue = By.cssSelector("input.button-1.new-address-next-step-button");

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
    }

    public void continueBilling() {
        driver.findElement(billingContinue).click();
    }
}
