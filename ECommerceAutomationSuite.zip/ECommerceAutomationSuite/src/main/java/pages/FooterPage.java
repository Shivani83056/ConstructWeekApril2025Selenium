package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class FooterPage {
    private WebDriver driver;

    private By facebookLink = By.cssSelector("a[href*='facebook']");
    private By twitterLink = By.cssSelector("a[href*='twitter']");
    private By sitemapLink = By.cssSelector("a[href='/sitemap']");

    public FooterPage(WebDriver driver) {
        this.driver = driver;
    }

    public void clickFacebook() {
        driver.findElement(facebookLink).click();
    }

    public void clickTwitter() {
        driver.findElement(twitterLink).click();
    }

    public void clickSitemap() {
        driver.findElement(sitemapLink).click();
    }
}
