package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ContactUsPage {
    private WebDriver driver;

    private By nameField = By.id("FullName");
    private By emailField = By.id("Email");
    private By messageField = By.id("Enquiry");
    private By submitButton = By.cssSelector("input[name='send-email']");

    public ContactUsPage(WebDriver driver) {
        this.driver = driver;
    }

    public void sendMessage(String name, String email, String message) {
        driver.findElement(nameField).sendKeys(name);
        driver.findElement(emailField).sendKeys(email);
        driver.findElement(messageField).sendKeys(message);
        driver.findElement(submitButton).click();
    }
}
