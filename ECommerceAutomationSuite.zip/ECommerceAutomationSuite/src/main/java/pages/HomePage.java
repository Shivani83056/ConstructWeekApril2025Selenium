package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
    private WebDriver driver;

    private By loginLink = By.cssSelector("a[href='/login']");
    private By registerLink = By.cssSelector("a[href='/register']");
    private By searchBox = By.id("small-searchterms");
    private By searchButton = By.cssSelector("input[value='Search']");

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public void clickLoginLink() {
        driver.findElement(loginLink).click();
    }

    public void clickRegisterLink() {
        driver.findElement(registerLink).click();
    }

    public void searchProduct(String product) {
        driver.findElement(searchBox).sendKeys(product);
        driver.findElement(searchButton).click();
    }
}
