package base;

import org.testng.annotations.*;

public class BaseTest {
    @BeforeMethod
    public void testBefore() {
        System.out.println("Before method executed");
    }

    @AfterMethod
    public void testAfter() {
        System.out.println("After method executed");
    }
}
