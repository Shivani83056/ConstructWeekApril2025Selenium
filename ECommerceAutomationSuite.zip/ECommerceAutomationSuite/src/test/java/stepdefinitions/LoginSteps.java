package stepdefinitions;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import factory.DriverFactory;
import pages.LoginPage;
import utilities.ConfigReader;

public class LoginSteps {

    private WebDriver driver;
    private LoginPage loginPage;

    @Before
    public void setUp() {
        // Read browser from config and launch
        String browser = ConfigReader.get("browser");
        driver = DriverFactory.initDriver(browser);
        loginPage = new LoginPage(driver);
    }

    @After
    public void tearDown() {
        DriverFactory.quitDriver();
    }

    @Given("the user is on the login page")
    public void the_user_is_on_the_login_page() {
        // Read base URL and navigate
        String baseUrl = ConfigReader.get("base.url");
        driver.get(baseUrl + "login");
    }

    @When("the user enters username {string} and password {string}")
    public void the_user_enters_username_and_password(String username, String password) {
        loginPage.enterEmail(username);
        loginPage.enterPassword(password);
    }

    @And("clicks the login button")
    public void clicks_the_login_button() {
        loginPage.clickLoginButton();
    }

    @Then("the user should be logged in successfully")
    public void the_user_should_be_logged_in_successfully() {
        // Simple check: page title or presence of account link
        String title = driver.getTitle();
        Assert.assertTrue(
            title.contains("My account") || title.contains("Demo Web Shop"),
            "Expected to be on account page, but was on: " + title
        );
    }

    @Then("an error message {string} should be displayed")
    public void an_error_message_should_be_displayed(String expectedMessage) {
        // You need a getErrorMessage() in LoginPage:
        String actual = loginPage.getErrorMessage();
        Assert.assertEquals(actual.trim(), expectedMessage);
    }
}
