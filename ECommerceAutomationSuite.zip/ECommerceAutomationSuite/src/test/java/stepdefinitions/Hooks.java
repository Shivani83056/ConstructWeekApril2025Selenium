package stepdefinitions;

import factory.DriverFactory;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks {

    @Before
    public void setUp() {
        new DriverFactory().initDriver("chrome"); // you can fetch from config
    }

    @After
    public void tearDown() {
        DriverFactory.getDriver().quit();
    }
}
