Feature: Checkout Process

  In order to complete a purchase
  As a shopper
  I want to go through the end-to-end order placement, including payment

  Scenario: Successful checkout with credit card
    Given the user has items in the cart
    And the user is logged in
    When the user proceeds to checkout
    And enters valid billing and shipping information
    And selects "Credit Card" as payment method
    And confirms the order
    Then an order confirmation page with order number should be displayed

  Scenario: Checkout validation for missing fields
    Given the user is on the checkout page
    When the user leaves the "City" field empty
    And tries to confirm the order
    Then an error message "City is required" should be displayed
