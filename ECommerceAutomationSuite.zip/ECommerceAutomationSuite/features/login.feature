Feature: User Authentication

  Scenario: Successful login
    Given the user is on the login page
    When the user enters username "testuser@example.com" and password "Test@123"
    And clicks the login button
    Then the user should be logged in successfully

  Scenario: Unsuccessful login
    Given the user is on the login page
    When the user enters username "wrong@example.com" and password "badpass"
    And clicks the login button
    Then an error message "Login was unsuccessful. Please correct the errors and try again." should be displayed
