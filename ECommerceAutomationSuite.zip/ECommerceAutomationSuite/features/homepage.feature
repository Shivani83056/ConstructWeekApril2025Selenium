Feature: Homepage

  In order to ensure the homepage displays correctly
  As a user
  I want to validate navigation menus, banners, and featured categories

  Scenario: Verify main navigation and banners
    Given the user navigates to the homepage
    Then the top navigation menu should be displayed
    And the promotional banner should be visible
    And the banner should link to the correct promotion page

  Scenario: Verify featured product categories
    Given the user is on the homepage
    When the user scrolls down to the featured categories section
    Then at least 3 featured categories should be displayed
    And each category should have an image and a title
