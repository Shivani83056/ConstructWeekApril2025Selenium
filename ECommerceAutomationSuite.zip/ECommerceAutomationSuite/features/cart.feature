Feature: Cart Operations

  In order to review and modify purchases
  As a shopper
  I want to add/remove items, update quantities, and see accurate totals

  Scenario: Add and remove items
    Given the user's cart is empty
    When the user adds "Build your own computer" to the cart
    Then the cart should show 1 item
    When the user removes the item
    Then the cart should be empty

  Scenario: Update item quantity and validate price
    Given the user has "Build your own computer" (quantity 1) in the cart
    When the user changes the quantity to 2
    And updates the cart
    Then the total price should be twice the unit price
