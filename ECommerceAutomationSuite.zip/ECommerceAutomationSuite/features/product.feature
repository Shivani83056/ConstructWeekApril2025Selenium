Feature: Product Page

  In order to view details and manage wishlist/cart
  As a shopper
  I want to navigate to product details, add to cart, and add to wishlist

  Scenario: View product details
    Given the user is on the search results page
    When the user clicks on a product named "Build your own computer"
    Then the product details page should be displayed
    And the product title and price should match the listing

  Scenario: Add product to cart
    Given the user is on a product details page
    When the user clicks "Add to cart"
    Then a confirmation message "The product has been added to your shopping cart" should appear

  Scenario: Add product to wishlist
    Given the user is on a product details page
    When the user clicks "Add to wishlist"
    Then a confirmation message "The product has been added to your wishlist" should appear
