Feature: Footer Section

  In order to access important links
  As a user
  I want to validate links like Privacy Policy and Contact Us

  Scenario: Verify Privacy Policy link
    Given the user is on any page
    When the user clicks the "Privacy Policy" link in the footer
    Then the Privacy Policy page should open in a new tab
    And the page title should contain "Privacy Policy"

  Scenario: Verify Contact Us link from footer
    Given the user is on any page
    When the user clicks the "Contact Us" link in the footer
    Then the Contact Us page should load
