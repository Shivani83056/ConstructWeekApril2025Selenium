Feature: Contact Us Form

  In order to send feedback or inquiries
  As a visitor
  I want to submit the contact form and see success or error messages

  Scenario: Successful form submission
    Given the user is on the Contact Us page
    When the user enters name "Shivani Singh", email "shivanisingh@example.com", and message "Test message"
    And clicks the Submit button
    Then a success message "Your enquiry has been successfully sent to the store owner." should appear

  Scenario: Form submission with invalid email
    Given the user is on the Contact Us page
    When the user enters name "Shivan Singh", email "invalid-email", and message "Test message"
    And clicks the Submit button
    Then an error message "Wrong email" should be displayed
