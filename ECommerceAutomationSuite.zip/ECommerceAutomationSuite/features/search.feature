Feature: Search and Product Filtering

  In order to find desired products easily
  As a shopper
  I want to search by keywords, filter by category, and sort results

  Scenario: Search by keyword
    Given the user is on the homepage
    When the user enters "laptop" into the search field
    And clicks the search button
    Then search results for "laptop" should be displayed

  Scenario: Filter results by category and price
    Given the user has searched for "laptop"
    When the user filters results by the category "Electronics"
    And sets the price range to "$500 - $1000"
    Then only products within that category and price range should be shown

  Scenario: Sort results by price low to high
    Given the user has search results
    When the user sorts results by "Price: Low to High"
    Then the first product’s price should be less than or equal to the second product’s price
